// create history
window.g_history = require('umi/_createHistory').default({
  basename: window.routerBase,
});
