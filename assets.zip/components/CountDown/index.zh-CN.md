---
title: CountDown 
subtitle: 倒计时
cols: 1
order: 3
---

倒计时组件。

## API

| 参数      | 说明                                      | 类型         | 默认值 |
|----------|------------------------------------------|-------------|-------|
| format | 时间格式化显示 | Function(time) |  |
| target | 目标时间 | Date | - |
| onEnd |  倒计时结束回调 | funtion | -|
